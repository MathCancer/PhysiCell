As of PhysiCell 1.2.2, the template projects have been moved 
to the sample projects. Look in: 

sample_projects/template2D

and 

sample_projects/template3D


To populate and compile the 2D template:

make reset <-- if you already populated a sample project 
make template2D
make 

To populate and compile the 3D template:

make reset <-- if you already populated a sample project 
make template3D
make 

